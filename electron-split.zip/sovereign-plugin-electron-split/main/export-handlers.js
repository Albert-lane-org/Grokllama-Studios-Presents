'use strict';

// Phase 3 — Export handlers (main process)
// Zip: archiver | PDF: printToPDF | PPTX: pptxgenjs | HTML: inline assets

const fs = require('fs');
const path = require('path');
const os = require('os');

function registerExportHandlers(ipcMain, dialog, getWindow) {
  function win() { return typeof getWindow === 'function' ? getWindow() : getWindow; }

  // ── ZIP ──────────────────────────────────────────────────────
  ipcMain.handle('export:zip', async (_e, vfsPath) => {
    const { canceled, filePath } = await dialog.showSaveDialog(win(), {
      title: 'Export project as ZIP',
      defaultPath: path.join(os.homedir(), 'Desktop', `${path.basename(vfsPath)}.zip`),
      filters: [{ name: 'ZIP Archive', extensions: ['zip'] }],
    });
    if (canceled || !filePath) return null;

    const archiver = require('archiver');
    const output = fs.createWriteStream(filePath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    await new Promise((resolve, reject) => {
      output.on('close', resolve);
      archive.on('error', reject);
      archive.pipe(output);
      archive.glob('**/*', {
        cwd: vfsPath,
        ignore: ['.enclave', '.marcohard-lock', 'node_modules/**'],
      });
      archive.finalize();
    });

    return filePath;
  });

  // ── PDF ──────────────────────────────────────────────────────
  ipcMain.handle('export:pdf', async () => {
    const w = win();
    if (!w) return null;
    const { canceled, filePath } = await dialog.showSaveDialog(w, {
      title: 'Export as PDF',
      defaultPath: path.join(os.homedir(), 'Desktop', 'claude-design-export.pdf'),
      filters: [{ name: 'PDF', extensions: ['pdf'] }],
    });
    if (canceled || !filePath) return null;

    const data = await w.webContents.printToPDF({
      printBackground: true,
      pageSize: 'A4',
      margins: { top: 20, bottom: 20, left: 20, right: 20 },
    });
    fs.writeFileSync(filePath, data);
    return filePath;
  });

  // ── PPTX ─────────────────────────────────────────────────────
  ipcMain.handle('export:pptx', async (_e, vfsPath) => {
    const { canceled, filePath } = await dialog.showSaveDialog(win(), {
      title: 'Export as PowerPoint',
      defaultPath: path.join(os.homedir(), 'Desktop', `${path.basename(vfsPath)}.pptx`),
      filters: [{ name: 'PowerPoint', extensions: ['pptx'] }],
    });
    if (canceled || !filePath) return null;

    const pptx = new (require('pptxgenjs'))();
    pptx.layout = 'LAYOUT_WIDE';

    // Title slide
    const slide = pptx.addSlide();
    slide.addText(path.basename(vfsPath), {
      x: 0.5, y: 2, w: '90%', h: 1.5,
      fontSize: 36, bold: true, color: 'FAF8F4',
      fontFace: 'Georgia',
    });
    slide.addText(`Claude Design export — ${new Date().toLocaleDateString()}`, {
      x: 0.5, y: 3.8, w: '90%',
      fontSize: 14, color: 'A09D98',
    });
    slide.background = { color: '1A2E45' };

    // One slide per file type category
    const cats = { PAGES: [], SCRIPTS: [], STYLESHEETS: [], DOCUMENTS: [], DATA: [], ASSETS: [] };
    function walk(dir) {
      try {
        for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
          if (['.git', 'node_modules', '.enclave'].includes(e.name)) continue;
          const full = path.join(dir, e.name);
          if (e.isDirectory()) walk(full);
          else {
            const ext = path.extname(e.name).toLowerCase();
            const cat = ({
              '.html': 'PAGES', '.htm': 'PAGES', '.css': 'STYLESHEETS',
              '.js': 'SCRIPTS', '.ts': 'SCRIPTS', '.jsx': 'SCRIPTS', '.tsx': 'SCRIPTS',
              '.md': 'DOCUMENTS', '.txt': 'DOCUMENTS',
              '.json': 'DATA', '.csv': 'DATA',
            })[ext] || 'ASSETS';
            cats[cat].push(path.relative(vfsPath, full));
          }
        }
      } catch {}
    }
    walk(vfsPath);

    for (const [cat, files] of Object.entries(cats)) {
      if (!files.length) continue;
      const s = pptx.addSlide();
      s.background = { color: '243C5A' };
      s.addText(cat, { x: 0.5, y: 0.4, w: '90%', fontSize: 20, bold: true, color: 'B8621A', fontFace: 'Georgia' });
      s.addText(files.join('\n'), {
        x: 0.5, y: 1.2, w: '90%', h: 4,
        fontSize: 11, color: 'FAF8F4', fontFace: 'Consolas',
        valign: 'top',
      });
    }

    await pptx.writeFile({ fileName: filePath });
    return filePath;
  });

  // ── Standalone HTML ──────────────────────────────────────────
  ipcMain.handle('export:standaloneHTML', async (_e, vfsPath) => {
    const { canceled, filePath } = await dialog.showSaveDialog(win(), {
      title: 'Export as standalone HTML',
      defaultPath: path.join(os.homedir(), 'Desktop', `${path.basename(vfsPath)}.html`),
      filters: [{ name: 'HTML', extensions: ['html'] }],
    });
    if (canceled || !filePath) return null;

    // Collect all HTML files in vfs, inline their CSS and JS
    function inlineAssets(html, baseDir) {
      // Inline <link rel="stylesheet">
      html = html.replace(/<link[^>]+rel=["']stylesheet["'][^>]*href=["']([^"']+)["'][^>]*>/gi, (_, href) => {
        if (href.startsWith('http')) return _;
        try {
          const css = fs.readFileSync(path.join(baseDir, href), 'utf8');
          return `<style>${css}</style>`;
        } catch { return _; }
      });
      // Inline <script src="...">
      html = html.replace(/<script([^>]*)src=["']([^"']+)["']([^>]*)><\/script>/gi, (_, pre, src, post) => {
        if (src.startsWith('http')) return _;
        try {
          const js = fs.readFileSync(path.join(baseDir, src), 'utf8');
          return `<script${pre}${post}>${js}</script>`;
        } catch { return _; }
      });
      return html;
    }

    // Find index.html or first HTML file
    let htmlFile = path.join(vfsPath, 'index.html');
    if (!fs.existsSync(htmlFile)) {
      const found = fs.readdirSync(vfsPath).find(f => f.endsWith('.html'));
      if (!found) {
        // Generate a simple file listing page
        const entries = [];
        function gatherEntries(dir) {
          for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
            if (['.git','node_modules'].includes(e.name)) continue;
            const rel = path.relative(vfsPath, path.join(dir, e.name));
            if (!e.isDirectory()) entries.push(rel);
            else gatherEntries(path.join(dir, e.name));
          }
        }
        gatherEntries(vfsPath);
        const listHtml = `<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>${path.basename(vfsPath)}</title>
<style>body{font-family:Georgia,serif;background:#1a2e45;color:#faf8f4;padding:2rem;max-width:800px;margin:auto}
h1{color:#b8621a}li{margin:.4rem 0;font-family:monospace}
</style></head><body>
<h1>${path.basename(vfsPath)}</h1>
<p style="color:#a09d98">Claude Design export — ${new Date().toLocaleDateString()}</p>
<ul>${entries.map(e => `<li>${e}</li>`).join('')}</ul>
</body></html>`;
        fs.writeFileSync(filePath, listHtml, 'utf8');
        return filePath;
      }
      htmlFile = path.join(vfsPath, found);
    }

    const raw = fs.readFileSync(htmlFile, 'utf8');
    const inlined = inlineAssets(raw, path.dirname(htmlFile));
    fs.writeFileSync(filePath, inlined, 'utf8');
    return filePath;
  });

  // ── Claude Code handoff ──────────────────────────────────────
  ipcMain.handle('export:claudeCode', async (_e, vfsPath) => {
    const handoff = {
      vfsPath,
      enclaveUUID: null, // populated from manifest if available
      exportedAt: new Date().toISOString(),
      command: `claude --project "${vfsPath}"`,
    };
    try {
      const manifest = JSON.parse(
        fs.readFileSync(path.join(vfsPath, '.enclave'), 'utf8')
      );
      handoff.enclaveUUID = manifest.uuid;
    } catch {}

    const handoffPath = path.join(vfsPath, 'handoff.json');
    fs.writeFileSync(handoffPath, JSON.stringify(handoff, null, 2), 'utf8');

    // Copy command to clipboard via a renderer event (main has no clipboard module here)
    win()?.webContents.send('export:handoffReady', handoff);
    return handoff;
  });
}

module.exports = { registerExportHandlers };
