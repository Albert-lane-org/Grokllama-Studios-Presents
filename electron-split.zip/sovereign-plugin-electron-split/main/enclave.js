'use strict';

// Phase 2 — Enclave Virtual Project
//
// Model: physical-local working copy + optional encrypted cloud redundancy.
// Source folder is read-only — only a .marcohard-lock is written there.
// All edits target the virtual copy at ~/.claude/projects/<slug>/
// Local always wins on conflict. Cloud stores AES-256-GCM ciphertext only.

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

// ── Helpers ──────────────────────────────────────────────────

function slugify(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'project';
}

function hashString(s) {
  return crypto.createHash('sha256').update(s, 'utf8').digest('hex');
}

function hashFile(filePath) {
  try {
    return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
  } catch {
    return null;
  }
}

const COPY_IGNORE = new Set(['.git', 'node_modules', '.marcohard-lock', 'dist', '.wrangler']);

function shouldIgnore(name) {
  return COPY_IGNORE.has(name) || name.startsWith('.enclave');
}

function buildChecksums(dir, base = dir, acc = {}) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return acc; }
  for (const e of entries) {
    if (shouldIgnore(e.name)) continue;
    const full = path.join(dir, e.name);
    const rel = path.relative(base, full);
    if (e.isDirectory()) buildChecksums(full, base, acc);
    else {
      const h = hashFile(full);
      if (h) acc[rel] = h;
    }
  }
  return acc;
}

function copyDir(src, dest, sendProgress) {
  fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const e of entries) {
    if (shouldIgnore(e.name)) continue;
    const s = path.join(src, e.name);
    const d = path.join(dest, e.name);
    if (e.isDirectory()) {
      copyDir(s, d, sendProgress);
    } else {
      fs.copyFileSync(s, d);
      sendProgress?.({ stage: 'copy', file: path.relative(src, s) });
    }
  }
}

// ── Manifest ─────────────────────────────────────────────────

function manifestPath(vfsRoot) {
  return path.join(vfsRoot, '.enclave');
}

function writeManifest(vfsRoot, manifest) {
  fs.writeFileSync(manifestPath(vfsRoot), JSON.stringify(manifest, null, 2), 'utf8');
}

function readManifest(vfsRoot) {
  try {
    return JSON.parse(fs.readFileSync(manifestPath(vfsRoot), 'utf8'));
  } catch {
    return null;
  }
}

// ── Device fingerprint key (deterministic, stays on device) ──

function deviceKey() {
  const seed = [os.hostname(), os.userInfo().username, os.homedir()].join('|');
  return crypto.createHash('sha256').update(seed, 'utf8').digest();
}

// ── Encrypt / Decrypt (AES-256-GCM) ─────────────────────────

function encryptBuffer(buf) {
  const key = deviceKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(buf), cipher.final()]);
  const tag = cipher.getAuthTag();
  // Layout: 12 bytes IV | 16 bytes tag | ciphertext
  return Buffer.concat([iv, tag, encrypted]);
}

function decryptBuffer(buf) {
  const key = deviceKey();
  const iv = buf.slice(0, 12);
  const tag = buf.slice(12, 28);
  const ciphertext = buf.slice(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

// ── Public API ────────────────────────────────────────────────

async function createEnclave(sourcePath, sendProgress) {
  const projectName = slugify(path.basename(sourcePath));
  const uuid = uuidv4();
  const vfsRoot = path.join(os.homedir(), '.claude', 'projects', projectName);

  // 2.1 Copy source → virtual working copy
  sendProgress?.({ stage: 'copy', message: `Creating virtual project at ${vfsRoot}…` });
  copyDir(sourcePath, vfsRoot, sendProgress);

  // 2.2 Build manifest with integrity checksums
  sendProgress?.({ stage: 'manifest', message: 'Computing checksums…' });
  const files = buildChecksums(vfsRoot);
  const manifest = {
    uuid,
    created: new Date().toISOString(),
    source_hash: hashString(sourcePath),
    svgFingerprint: 'pending-scope',
    files,
  };
  writeManifest(vfsRoot, manifest);

  // 2.3 Drop read-only lock in source (single file, nothing else written)
  const lockPath = path.join(sourcePath, '.marcohard-lock');
  if (!fs.existsSync(lockPath)) {
    fs.writeFileSync(lockPath, JSON.stringify({ uuid, created: manifest.created, vfsPath: vfsRoot }), 'utf8');
  }

  sendProgress?.({ stage: 'done', vfsPath: vfsRoot, uuid, projectName });
  return { vfsPath: vfsRoot, uuid, projectName };
}

// 2.4 Dirty tracking — compare live file hash vs manifest baseline
function getDirtyFiles(vfsRoot) {
  const manifest = readManifest(vfsRoot);
  if (!manifest) return [];
  const dirty = [];
  for (const [rel, expectedHash] of Object.entries(manifest.files)) {
    const full = path.join(vfsRoot, rel);
    const currentHash = hashFile(full);
    if (currentHash && currentHash !== expectedHash) dirty.push(rel);
    if (!currentHash) dirty.push(rel); // deleted
  }
  return dirty;
}

// Update manifest checksums after a save
function updateManifestChecksums(vfsRoot, changedRelPaths) {
  const manifest = readManifest(vfsRoot);
  if (!manifest) return;
  for (const rel of changedRelPaths) {
    const full = path.join(vfsRoot, rel);
    const h = hashFile(full);
    if (h) manifest.files[rel] = h;
  }
  manifest.lastSaved = new Date().toISOString();
  writeManifest(vfsRoot, manifest);
}

// 2.5 Cloud redundancy — encrypt a single file and return ciphertext buffer
// Actual upload to Claude Projects API wired in Phase 2.5 (requires API key)
function encryptFileForCloud(vfsRoot, relativePath) {
  const full = path.join(vfsRoot, relativePath);
  const buf = fs.readFileSync(full);
  return encryptBuffer(buf);
}

function decryptFileFromCloud(ciphertextBuf) {
  return decryptBuffer(ciphertextBuf);
}

// State query
function getEnclaveState(vfsRoot) {
  if (!vfsRoot) return { active: false };
  const manifest = readManifest(vfsRoot);
  if (!manifest) return { active: false };
  const dirty = getDirtyFiles(vfsRoot);
  return {
    active: true,
    uuid: manifest.uuid,
    projectName: path.basename(vfsRoot),
    vfsPath: vfsRoot,
    created: manifest.created,
    lastSaved: manifest.lastSaved || null,
    dirtyCount: dirty.length,
    dirty,
  };
}

function readEnclaveManifest(vfsRoot) {
  return readManifest(vfsRoot);
}

module.exports = {
  createEnclave,
  getEnclaveState,
  getDirtyFiles,
  updateManifestChecksums,
  encryptFileForCloud,
  decryptFileFromCloud,
  readEnclaveManifest,
};
