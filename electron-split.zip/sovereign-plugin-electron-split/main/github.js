'use strict';

// Phase 5 — GitHub Integration (REST Phase 1, GraphQL noted for full buildout)
// OAuth callback received via claude-design:// custom protocol
// PAT stored in electron-store (encrypted by OS keychain via safeStorage in Phase 5)

async function fetchRepoTree(owner, repo, sha, token) {
  const res = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/git/trees/${sha}?recursive=1`,
    { headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json' } }
  );
  if (!res.ok) throw new Error(`GitHub API ${res.status}: ${await res.text()}`);
  const data = await res.json();
  return data.tree || [];
}

async function listBranches(owner, repo, token) {
  const res = await fetch(
    `https://api.github.com/repos/${owner}/${repo}/branches`,
    { headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json' } }
  );
  if (!res.ok) throw new Error(`GitHub API ${res.status}`);
  return res.json();
}

module.exports = { fetchRepoTree, listBranches };
