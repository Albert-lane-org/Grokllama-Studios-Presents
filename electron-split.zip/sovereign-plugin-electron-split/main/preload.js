'use strict';

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Window
  windowMinimize: () => ipcRenderer.send('window:minimize'),
  windowMaximize: () => ipcRenderer.send('window:maximize'),
  windowClose:    () => ipcRenderer.send('window:close'),
  onWindowMaximized: (cb) => ipcRenderer.on('window:maximized', (_e, v) => cb(v)),

  // Filesystem
  openFolder:   () => ipcRenderer.invoke('dialog:openFolder'),
  importFiles:  () => ipcRenderer.invoke('dialog:importFiles'),
  readFileTree: (p) => ipcRenderer.invoke('fs:readFileTree', p),

  // Import pipeline (Phase 3)
  processImport: (paths, vfsPath, overrideUnsafe) =>
    ipcRenderer.invoke('import:files', paths, vfsPath, overrideUnsafe),

  // Security
  scanFile: (filePath, vfsPath) => ipcRenderer.invoke('security:scanFile', filePath, vfsPath),
  scanText: (text, label)       => ipcRenderer.invoke('security:scanText', text, label),

  // Enclave (Phase 2)
  createEnclave:       (src)           => ipcRenderer.invoke('enclave:create', src),
  onEnclaveProgress:   (cb)            => ipcRenderer.on('enclave:progress', (_e, v) => cb(v)),
  getEnclaveState:     (vfsPath)       => ipcRenderer.invoke('enclave:getState', vfsPath),
  readEnclaveManifest: (vfsPath)       => ipcRenderer.invoke('enclave:readManifest', vfsPath),
  saveFile:  (vfsPath, rel, text)      => ipcRenderer.invoke('enclave:saveFile', vfsPath, rel, text),
  readFile:  (vfsPath, rel)            => ipcRenderer.invoke('enclave:readFile', vfsPath, rel),

  // Export (Phase 3)
  exportZip:          (vfsPath) => ipcRenderer.invoke('export:zip', vfsPath),
  exportPDF:          ()        => ipcRenderer.invoke('export:pdf'),
  exportPPTX:         (vfsPath) => ipcRenderer.invoke('export:pptx', vfsPath),
  exportStandaloneHTML:(vfsPath)=> ipcRenderer.invoke('export:standaloneHTML', vfsPath),
  handoffToClaudeCode:(vfsPath) => ipcRenderer.invoke('export:claudeCode', vfsPath),
  onHandoffReady: (cb) => ipcRenderer.on('export:handoffReady', (_e, v) => cb(v)),

  // Clipboard
  readClipboardText: () => ipcRenderer.invoke('clipboard:readText'),

  // Settings
  getSetting: (k)    => ipcRenderer.invoke('store:get', k),
  setSetting: (k, v) => ipcRenderer.invoke('store:set', k, v),

  // Sketch (Phase 4)
  savePNG: (vfsPath, name, dataUrl) => ipcRenderer.invoke('sketch:savePNG', vfsPath, name, dataUrl),
  saveSVG: (vfsPath, name, svgXml)  => ipcRenderer.invoke('sketch:saveSVG', vfsPath, name, svgXml),
});
