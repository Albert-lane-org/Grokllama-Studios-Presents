'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { clipboard } = require('electron');
const { createEnclave, getEnclaveState, readEnclaveManifest, updateManifestChecksums } = require('./enclave');
const { scanFile, scanText, validateDestPath, buildSecurityReport } = require('./security-scanner');

const EXT_MAP = {
  '.html': 'PAGES', '.htm': 'PAGES',
  '.css': 'STYLESHEETS',
  '.md': 'DOCUMENTS', '.txt': 'DOCUMENTS', '.pdf': 'DOCUMENTS',
  '.docx': 'DOCUMENTS', '.doc': 'DOCUMENTS',
  '.json': 'DATA', '.csv': 'DATA', '.xml': 'DATA', '.yaml': 'DATA', '.yml': 'DATA',
  '.js': 'SCRIPTS', '.ts': 'SCRIPTS', '.jsx': 'SCRIPTS', '.tsx': 'SCRIPTS', '.mjs': 'SCRIPTS',
  '.png': 'ASSETS', '.jpg': 'ASSETS', '.jpeg': 'ASSETS', '.gif': 'ASSETS', '.webp': 'ASSETS',
  '.svg': 'ASSETS', '.ico': 'ASSETS', '.woff': 'ASSETS', '.woff2': 'ASSETS',
  '.ttf': 'ASSETS', '.otf': 'ASSETS', '.mp4': 'ASSETS', '.mp3': 'ASSETS', '.wav': 'ASSETS',
};

const IGNORED = new Set([
  '.git', 'node_modules', '.enclave', 'dist', '.wrangler', '.marcohard-lock',
]);

function classifyEntry(entryPath, stat) {
  if (stat.isDirectory()) return 'FOLDERS';
  const ext = path.extname(entryPath).toLowerCase();
  return EXT_MAP[ext] || 'DOCUMENTS';
}

function walkDir(dirPath, baseDir, results = []) {
  let entries;
  try { entries = fs.readdirSync(dirPath, { withFileTypes: true }); }
  catch { return results; }
  for (const entry of entries) {
    if (IGNORED.has(entry.name)) continue;
    const full = path.join(dirPath, entry.name);
    const relative = path.relative(baseDir, full);
    let stat;
    try { stat = fs.statSync(full); } catch { continue; }
    const category = classifyEntry(full, stat);
    results.push({
      name: entry.name,
      path: full,
      relative,
      category,
      isDir: stat.isDirectory(),
      mtime: stat.mtime.toISOString(),
      size: stat.isDirectory() ? null : stat.size,
    });
    if (stat.isDirectory()) walkDir(full, baseDir, results);
  }
  return results;
}

let Store, store;
async function getStore() {
  if (store) return store;
  const mod = await import('electron-store');
  Store = mod.default;
  store = new Store({ name: 'claude-design-prefs' });
  return store;
}

function registerAllHandlers(ipcMain, dialog, getWindow) {
  function win() { return typeof getWindow === 'function' ? getWindow() : getWindow; }

  // ── Folder / file dialog ─────────────────────────────────────
  ipcMain.handle('dialog:openFolder', async () => {
    const result = await dialog.showOpenDialog(win(), {
      properties: ['openDirectory'],
      title: 'Open Project Folder',
    });
    if (result.canceled || !result.filePaths.length) return null;
    return result.filePaths[0];
  });

  ipcMain.handle('dialog:importFiles', async () => {
    const result = await dialog.showOpenDialog(win(), {
      properties: ['openFile', 'multiSelections'],
      title: 'Import Files',
    });
    if (result.canceled || !result.filePaths.length) return [];
    return result.filePaths;
  });

  // ── File tree ────────────────────────────────────────────────
  ipcMain.handle('fs:readFileTree', async (_e, folderPath) => {
    if (!folderPath) return [];
    return walkDir(folderPath, folderPath);
  });

  // ── Import + security scan ───────────────────────────────────
  // Returns { imported: Entry[], scanReport: SecurityReport }
  // Files flagged CRITICAL/HIGH are quarantined (not copied) unless user overrides.
  ipcMain.handle('import:files', async (_e, filePaths, vfsPath, overrideUnsafe = false) => {
    const results = [];
    const scanResults = [];
    const w = win();

    for (const src of filePaths) {
      const name = path.basename(src);
      const ext = path.extname(name).toLowerCase();
      const category = EXT_MAP[ext] || 'DOCUMENTS';

      // Security scan before touching vfs
      let scanResult;
      try {
        scanResult = scanFile(src, vfsPath);
      } catch (err) {
        results.push({ name, src, status: 'error', reason: err.message });
        continue;
      }
      scanResults.push({ file: src, ...scanResult });

      if (scanResult.blocked) {
        results.push({ name, src, status: 'blocked', reason: scanResult.reason, findings: [] });
        continue;
      }

      if (!scanResult.safe && !overrideUnsafe) {
        results.push({
          name, src, status: 'quarantined',
          findings: scanResult.findings,
          reason: `${scanResult.findings.filter(f => ['CRITICAL','HIGH'].includes(f.severity)).length} critical/high finding(s)`,
        });
        continue;
      }

      // Safe (or override) — copy into vfs
      if (vfsPath) {
        try {
          validateDestPath(vfsPath, name);
          const dest = path.join(vfsPath, name);
          fs.mkdirSync(path.dirname(dest), { recursive: true });
          fs.copyFileSync(src, dest);
          updateManifestChecksums(vfsPath, [name]);
        } catch (err) {
          results.push({ name, src, status: 'error', reason: err.message, findings: scanResult.findings });
          continue;
        }
      }

      results.push({
        name, src, status: scanResult.safe ? 'clean' : 'imported-with-warnings',
        category,
        hash: scanResult.hash,
        mime: scanResult.mime,
        sizeBytes: scanResult.sizeBytes,
        findings: scanResult.findings,
        relative: name,
      });
    }

    const securityReport = buildSecurityReport(scanResults);
    return { imported: results, securityReport };
  });

  // ── Secure file save (enclave write) ─────────────────────────
  ipcMain.handle('enclave:saveFile', async (_e, vfsPath, relativePath, content) => {
    // Path traversal guard
    let dest;
    try {
      dest = validateDestPath(vfsPath, relativePath);
    } catch (err) {
      throw new Error(`Security: ${err.message}`);
    }

    // Scan text content before write
    const { safe, findings } = scanText(content, relativePath);
    if (!safe) {
      const critical = findings.filter(f => ['CRITICAL','HIGH'].includes(f.severity));
      throw new Error(`Security: ${critical.length} critical/high finding(s) blocked save — ${critical[0]?.label}`);
    }

    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, content, 'utf8');
    updateManifestChecksums(vfsPath, [relativePath]);
    return dest;
  });

  ipcMain.handle('enclave:readFile', async (_e, vfsPath, relativePath) => {
    let src;
    try { src = validateDestPath(vfsPath, relativePath); } catch { return null; }
    try { return fs.readFileSync(src, 'utf8'); } catch { return null; }
  });

  // ── Scan a single file on demand ─────────────────────────────
  ipcMain.handle('security:scanFile', async (_e, filePath, vfsPath) => {
    try { return scanFile(filePath, vfsPath); }
    catch (err) { return { safe: false, blocked: true, reason: err.message, findings: [] }; }
  });

  ipcMain.handle('security:scanText', async (_e, text, label) => {
    return scanText(text, label);
  });

  // ── Clipboard ────────────────────────────────────────────────
  ipcMain.handle('clipboard:readText', () => clipboard.readText() || '');

  // ── Store ────────────────────────────────────────────────────
  ipcMain.handle('store:get', async (_e, key) => { const s = await getStore(); return s.get(key); });
  ipcMain.handle('store:set', async (_e, key, val) => { const s = await getStore(); s.set(key, val); });

  // ── Enclave lifecycle ────────────────────────────────────────
  ipcMain.handle('enclave:create', async (event, sourcePath) => {
    const sendProgress = (payload) => {
      try { win()?.webContents.send('enclave:progress', payload); } catch {}
    };
    return createEnclave(sourcePath, sendProgress);
  });
  ipcMain.handle('enclave:getState', async (_e, vfsPath) => getEnclaveState(vfsPath));
  ipcMain.handle('enclave:readManifest', async (_e, vfsPath) => readEnclaveManifest(vfsPath));

  // ── Sketch save ──────────────────────────────────────────────
  ipcMain.handle('sketch:savePNG', async (_e, vfsPath, name, dataUrl) => {
    const dir = vfsPath ? path.join(vfsPath, 'sketches') : path.join(os.homedir(), '.claude', 'sketches');
    fs.mkdirSync(dir, { recursive: true });
    const buf = Buffer.from(dataUrl.replace(/^data:image\/png;base64,/, ''), 'base64');
    const dest = path.join(dir, `${name}.png`);
    fs.writeFileSync(dest, buf);
    return dest;
  });

  ipcMain.handle('sketch:saveSVG', async (_e, vfsPath, name, svgXml) => {
    // Scan SVG for embedded scripts before save
    const { safe, findings } = scanText(svgXml, `${name}.svg`);
    if (!safe) throw new Error(`Security: SVG contains active content — save blocked`);
    const dir = vfsPath ? path.join(vfsPath, 'sketches') : path.join(os.homedir(), '.claude', 'sketches');
    fs.mkdirSync(dir, { recursive: true });
    const dest = path.join(dir, `${name}.svg`);
    fs.writeFileSync(dest, svgXml, 'utf8');
    return dest;
  });

  // Window controls (re-registered here for completeness)
  ipcMain.removeAllListeners('window:minimize');
  ipcMain.removeAllListeners('window:maximize');
  ipcMain.removeAllListeners('window:close');
}

module.exports = { registerAllHandlers };
