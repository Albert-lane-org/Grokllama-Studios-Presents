'use strict';

// Enterprise-grade file security scanner
//
// Threat model: a user imports an arbitrary file from disk or clipboard.
// Attacker goals: code execution via Electron contextBridge leak, prototype
// pollution, path traversal escape from vfs root, exfiltration via embedded
// URLs, or malicious SVG/HTML that runs when rendered.
//
// This module is MAIN-PROCESS ONLY — never exposed to renderer.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ── Constants ─────────────────────────────────────────────────

const MAX_FILE_BYTES = 16 * 1024 * 1024; // 16 MB hard cap
const MAX_SCAN_BYTES = 2 * 1024 * 1024;  // read up to 2 MB for pattern matching

const SEVERITY = { CRITICAL: 'CRITICAL', HIGH: 'HIGH', MEDIUM: 'MEDIUM', LOW: 'LOW', INFO: 'INFO' };

// ── Threat signatures ─────────────────────────────────────────
// Modelled on sovereign-plugin's 22-pattern threat detection, extended for
// file content (vs HTTP request payloads).

const SIGNATURES = [
  // Remote code / eval
  { id: 'S01', severity: SEVERITY.CRITICAL, label: 'eval() usage',              pattern: /\beval\s*\(/ },
  { id: 'S02', severity: SEVERITY.CRITICAL, label: 'Function() constructor',    pattern: /new\s+Function\s*\(/ },
  { id: 'S03', severity: SEVERITY.CRITICAL, label: 'setTimeout string eval',    pattern: /setTimeout\s*\(\s*['"`]/ },
  { id: 'S04', severity: SEVERITY.CRITICAL, label: 'setInterval string eval',   pattern: /setInterval\s*\(\s*['"`]/ },

  // Node / Electron privilege escalation
  { id: 'S05', severity: SEVERITY.CRITICAL, label: 'require() call in content', pattern: /\brequire\s*\(\s*['"`](?:child_process|fs|path|os|net|http|https|electron)/ },
  { id: 'S06', severity: SEVERITY.CRITICAL, label: 'process.env access',        pattern: /\bprocess\.env\b/ },
  { id: 'S07', severity: SEVERITY.CRITICAL, label: '__dirname / __filename',    pattern: /\b(__dirname|__filename)\b/ },
  { id: 'S08', severity: SEVERITY.HIGH,     label: 'ipcRenderer direct call',   pattern: /ipcRenderer\.(send|invoke|on)\s*\(/ },
  { id: 'S09', severity: SEVERITY.HIGH,     label: 'contextBridge exposure',    pattern: /contextBridge\.exposeInMainWorld/ },
  { id: 'S10', severity: SEVERITY.HIGH,     label: 'shell.openExternal',        pattern: /shell\.openExternal/ },

  // XSS / DOM injection
  { id: 'S11', severity: SEVERITY.HIGH,     label: 'innerHTML assignment',      pattern: /\.innerHTML\s*=/ },
  { id: 'S12', severity: SEVERITY.HIGH,     label: 'document.write()',          pattern: /document\.write\s*\(/ },
  { id: 'S13', severity: SEVERITY.HIGH,     label: 'javascript: URI',           pattern: /javascript\s*:/i },
  { id: 'S14', severity: SEVERITY.HIGH,     label: 'data: URI script',          pattern: /data\s*:\s*text\/html/i },
  { id: 'S15', severity: SEVERITY.HIGH,     label: 'SVG script element',        pattern: /<script[\s>]/i },
  { id: 'S16', severity: SEVERITY.HIGH,     label: 'onload / onerror handler',  pattern: /\bon(?:load|error|click|mouse\w+)\s*=/i },

  // Path traversal
  { id: 'S17', severity: SEVERITY.HIGH,     label: 'Path traversal sequence',   pattern: /\.\.[\/\\]/ },
  { id: 'S18', severity: SEVERITY.MEDIUM,   label: 'Absolute path reference',   pattern: /(?:^|['"`])\/(?:etc|proc|sys|dev|tmp|var|usr|home)\// },

  // Obfuscation
  { id: 'S19', severity: SEVERITY.MEDIUM,   label: 'Base64 decode pattern',     pattern: /atob\s*\(|Buffer\.from\s*\([^,]+,\s*['"]base64['"]/ },
  { id: 'S20', severity: SEVERITY.MEDIUM,   label: 'Hex string blob',           pattern: /(?:0x[0-9a-f]{8,}){3,}/i },
  { id: 'S21', severity: SEVERITY.MEDIUM,   label: 'Unicode escape flood',      pattern: /(?:\\u[0-9a-f]{4}){6,}/i },

  // Exfiltration
  { id: 'S22', severity: SEVERITY.MEDIUM,   label: 'fetch() to external host',  pattern: /fetch\s*\(\s*['"`]https?:\/\/(?!localhost|127\.0\.0\.1)/ },
  { id: 'S23', severity: SEVERITY.MEDIUM,   label: 'XMLHttpRequest open()',     pattern: /\.open\s*\(\s*['"`](?:GET|POST)['"`]\s*,\s*['"`]https?:/ },
  { id: 'S24', severity: SEVERITY.MEDIUM,   label: 'WebSocket external',        pattern: /new\s+WebSocket\s*\(\s*['"`]wss?:\/\/(?!localhost)/ },

  // Prototype pollution
  { id: 'S25', severity: SEVERITY.HIGH,     label: 'Prototype pollution',       pattern: /(?:__proto__|constructor\.prototype)\s*\[/ },

  // Credential patterns
  { id: 'S26', severity: SEVERITY.LOW,      label: 'Hardcoded secret keyword',  pattern: /(?:password|secret|api_?key|token|private_?key)\s*[:=]\s*['"`][^'"`]{8,}['"`]/i },
  { id: 'S27', severity: SEVERITY.LOW,      label: 'AWS access key pattern',    pattern: /AKIA[0-9A-Z]{16}/ },

  // SSRF / open redirect
  { id: 'S28', severity: SEVERITY.MEDIUM,   label: 'SSRF localhost redirect',   pattern: /https?:\/\/(?:127\.0\.0\.1|0\.0\.0\.0|localhost):\d{2,5}/ },
];

// ── MIME / extension whitelist ────────────────────────────────

const ALLOWED_EXTENSIONS = new Set([
  '.html', '.htm', '.css', '.js', '.ts', '.jsx', '.tsx', '.mjs',
  '.json', '.csv', '.xml', '.yaml', '.yml',
  '.md', '.txt', '.pdf', '.doc', '.docx',
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico',
  '.woff', '.woff2', '.ttf', '.otf',
  '.mp4', '.mp3', '.wav',
  '.zip', '.tar', '.gz',
]);

// Magic-byte MIME detection (first 8 bytes)
const MAGIC = [
  { bytes: [0x89, 0x50, 0x4e, 0x47], mime: 'image/png' },
  { bytes: [0xff, 0xd8, 0xff],       mime: 'image/jpeg' },
  { bytes: [0x47, 0x49, 0x46],       mime: 'image/gif' },
  { bytes: [0x25, 0x50, 0x44, 0x46], mime: 'application/pdf' },
  { bytes: [0x50, 0x4b, 0x03, 0x04], mime: 'application/zip' },
  { bytes: [0x4d, 0x5a],             mime: 'application/exe' }, // PE executable — blocked
  { bytes: [0x7f, 0x45, 0x4c, 0x46], mime: 'application/elf' }, // ELF — blocked
];

const BLOCKED_MIMES = new Set(['application/exe', 'application/elf']);

function detectMime(buf) {
  for (const { bytes, mime } of MAGIC) {
    if (bytes.every((b, i) => buf[i] === b)) return mime;
  }
  return 'text/plain';
}

// ── Path safety ───────────────────────────────────────────────

function assertWithinRoot(vfsRoot, targetPath) {
  const resolved = path.resolve(targetPath);
  const root = path.resolve(vfsRoot);
  if (!resolved.startsWith(root + path.sep) && resolved !== root) {
    throw new Error(`Path traversal detected: ${targetPath} escapes ${vfsRoot}`);
  }
}

// ── Content scanner ───────────────────────────────────────────

function scanContent(text, filePath) {
  const findings = [];
  for (const sig of SIGNATURES) {
    const match = sig.pattern.exec(text);
    if (match) {
      // Estimate line number
      const before = text.slice(0, match.index);
      const line = before.split('\n').length;
      findings.push({
        id: sig.id,
        severity: sig.severity,
        label: sig.label,
        file: filePath,
        line,
        excerpt: match[0].slice(0, 80),
      });
    }
  }
  return findings;
}

// ── Binary check ──────────────────────────────────────────────

function isBinary(buf) {
  // Heuristic: >30% non-printable non-whitespace bytes in first 512 = binary
  const sample = buf.slice(0, 512);
  let nonPrint = 0;
  for (const b of sample) {
    if (b < 0x09 || (b > 0x0d && b < 0x20) || b === 0x7f) nonPrint++;
  }
  return nonPrint / sample.length > 0.30;
}

// ── Main export ───────────────────────────────────────────────

/**
 * Scan a file before writing it into the enclave.
 * Returns { safe: boolean, findings: Finding[], hash: string, mime: string, sizeBytes: number }
 * Throws on hard blocks (executable, path traversal, oversized).
 */
function scanFile(filePath, vfsRoot) {
  // Extension check
  const ext = path.extname(filePath).toLowerCase();
  if (ext && !ALLOWED_EXTENSIONS.has(ext)) {
    return {
      safe: false,
      blocked: true,
      reason: `Extension '${ext}' is not on the allowlist`,
      findings: [],
      hash: null,
      mime: null,
      sizeBytes: 0,
    };
  }

  // Size check
  let stat;
  try { stat = fs.statSync(filePath); } catch (e) {
    throw new Error(`Cannot stat file: ${filePath} — ${e.message}`);
  }
  if (stat.size > MAX_FILE_BYTES) {
    return {
      safe: false,
      blocked: true,
      reason: `File exceeds 16 MB limit (${(stat.size / 1024 / 1024).toFixed(1)} MB)`,
      findings: [],
      hash: null,
      mime: null,
      sizeBytes: stat.size,
    };
  }

  const buf = fs.readFileSync(filePath);
  const hash = crypto.createHash('sha256').update(buf).digest('hex');

  // MIME magic check
  const mime = detectMime(buf);
  if (BLOCKED_MIMES.has(mime)) {
    return {
      safe: false,
      blocked: true,
      reason: `Blocked MIME type: ${mime} (executable)`,
      findings: [],
      hash,
      mime,
      sizeBytes: stat.size,
    };
  }

  // Binary files: skip content scan, mark safe
  if (isBinary(buf)) {
    return { safe: true, blocked: false, findings: [], hash, mime, sizeBytes: stat.size };
  }

  // Text content scan
  const text = buf.slice(0, MAX_SCAN_BYTES).toString('utf8');
  const findings = scanContent(text, filePath);

  const criticalOrHigh = findings.filter(
    (f) => f.severity === SEVERITY.CRITICAL || f.severity === SEVERITY.HIGH
  );

  return {
    safe: criticalOrHigh.length === 0,
    blocked: false,
    findings,
    hash,
    mime,
    sizeBytes: stat.size,
  };
}

/**
 * Scan a raw content string (clipboard paste, split output, etc.)
 * Returns { safe, findings }
 */
function scanText(text, label = 'clipboard') {
  const findings = scanContent(text, label);
  const criticalOrHigh = findings.filter(
    (f) => f.severity === SEVERITY.CRITICAL || f.severity === SEVERITY.HIGH
  );
  return { safe: criticalOrHigh.length === 0, findings };
}

/**
 * Validate a destination path is inside the vfs root.
 * Throws SecurityError on traversal attempt.
 */
function validateDestPath(vfsRoot, relativePath) {
  if (/\.\.[\/\\]/.test(relativePath)) {
    throw new Error(`Security: path traversal in relative path: ${relativePath}`);
  }
  const dest = path.join(vfsRoot, relativePath);
  assertWithinRoot(vfsRoot, dest);
  return dest;
}

/**
 * Build a security report for writing into the .enclave manifest.
 */
function buildSecurityReport(scanResults) {
  const total = scanResults.length;
  const byId = {};
  for (const r of scanResults) {
    for (const f of r.findings) {
      byId[f.id] = (byId[f.id] || 0) + 1;
    }
  }
  const counts = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, INFO: 0 };
  for (const r of scanResults) {
    for (const f of r.findings) counts[f.severity] = (counts[f.severity] || 0) + 1;
  }
  return {
    scannedAt: new Date().toISOString(),
    filesScanned: total,
    findingCounts: counts,
    topSignatures: Object.entries(byId).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([id, n]) => ({ id, count: n })),
    clean: counts.CRITICAL === 0 && counts.HIGH === 0,
  };
}

module.exports = { scanFile, scanText, validateDestPath, buildSecurityReport, SEVERITY, SIGNATURES };
