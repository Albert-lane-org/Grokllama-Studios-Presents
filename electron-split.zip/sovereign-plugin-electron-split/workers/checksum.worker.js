// Phase 2 — Web Worker for background file checksums
// Receives { type: 'checksum', files: [{path, content: ArrayBuffer}] }
// Posts back { type: 'result', checksums: { path: hex } }

self.onmessage = async (e) => {
  if (e.data.type !== 'checksum') return;
  const results = {};
  for (const { path, content } of e.data.files) {
    const hashBuf = await crypto.subtle.digest('SHA-256', content);
    const hex = Array.from(new Uint8Array(hashBuf)).map((b) => b.toString(16).padStart(2, '0')).join('');
    results[path] = hex;
  }
  self.postMessage({ type: 'result', checksums: results });
};
