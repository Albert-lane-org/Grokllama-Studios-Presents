// Phase 3 — Web Worker for file split logic
// Receives { type: 'split', fileName, content: string }
// Posts back { type: 'result', pieces: [{name, content, category}] }

self.onmessage = (e) => {
  if (e.data.type !== 'split') return;
  const { fileName, content } = e.data;
  const ext = fileName.split('.').pop()?.toLowerCase();
  let pieces = [];

  if (ext === 'css') pieces = splitCSS(fileName, content);
  else if (ext === 'html' || ext === 'htm') pieces = splitHTML(fileName, content);
  else if (['js', 'ts', 'jsx', 'tsx', 'mjs'].includes(ext)) pieces = splitJS(fileName, content);

  self.postMessage({ type: 'result', pieces });
};

function splitCSS(name, content) {
  const base = name.replace(/\.[^.]+$/, '');
  const varBlock = content.match(/:root\s*\{[^}]*\}/s)?.[0] || '';
  const layoutBlock = content.match(/\/\*\s*layout[\s\S]*?(?=\/\*|$)/i)?.[0] || '';
  return [
    { name: `${base}.variables.css`, content: varBlock || '/* variables */', category: 'STYLESHEETS' },
    { name: `${base}.layout.css`, content: layoutBlock || '/* layout */', category: 'STYLESHEETS' },
    { name: `${base}.components.css`, content: '/* components */', category: 'STYLESHEETS' },
    { name: `${base}.utilities.css`, content: '/* utilities */', category: 'STYLESHEETS' },
  ].filter((p) => p.content.trim().length > 0);
}

function splitHTML(name, content) {
  const base = name.replace(/\.[^.]+$/, '');
  const styleMatch = content.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
  const scriptMatch = content.match(/<script[^>]*>([\s\S]*?)<\/script>/i);
  const markup = content
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
  return [
    { name: `${base}.markup.html`, content: markup.trim(), category: 'PAGES' },
    styleMatch && { name: `${base}.embedded.css`, content: styleMatch[1].trim(), category: 'STYLESHEETS' },
    scriptMatch && { name: `${base}.embedded.js`, content: scriptMatch[1].trim(), category: 'SCRIPTS' },
  ].filter(Boolean);
}

function splitJS(name, content) {
  const base = name.replace(/\.[^.]+$/, '');
  const ext = name.split('.').pop();
  // Naive section split by comment markers
  const sections = { components: [], logic: [], styles: [], constants: [] };
  let current = 'logic';
  for (const line of content.split('\n')) {
    if (/\/\/\s*components?/i.test(line)) current = 'components';
    else if (/\/\/\s*(logic|utils?)/i.test(line)) current = 'logic';
    else if (/\/\/\s*styles?/i.test(line)) current = 'styles';
    else if (/\/\/\s*constants?/i.test(line)) current = 'constants';
    sections[current].push(line);
  }
  return Object.entries(sections)
    .filter(([, lines]) => lines.some((l) => l.trim()))
    .map(([section, lines]) => ({
      name: `${base}.${section}.${ext}`,
      content: lines.join('\n').trim(),
      category: 'SCRIPTS',
    }));
}
