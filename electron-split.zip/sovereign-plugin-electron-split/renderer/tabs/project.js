'use strict';

const projectMain = document.getElementById('project-main');

document.addEventListener('file:selected', (e) => {
  const entry = e.detail;
  projectMain.innerHTML = `
    <div style="
      background: var(--navy-mid);
      border: 1px solid var(--border-mid);
      border-radius: var(--radius-lg);
      padding: var(--gap-xl);
      max-width: 560px;
      width: 90%;
    ">
      <div style="
        font-family: var(--font-display);
        font-size: var(--text-lg);
        color: var(--cream);
        margin-bottom: var(--gap-md);
      ">${entry.name}</div>
      <table style="
        width: 100%;
        font-size: var(--text-sm);
        border-collapse: collapse;
        color: var(--ink-muted);
      ">
        <tr>
          <td style="padding: var(--gap-xs) var(--gap-md) var(--gap-xs) 0; color: var(--ink-faint); font-family: var(--font-mono); font-size: var(--text-xs);">PATH</td>
          <td style="padding: var(--gap-xs) 0; word-break: break-all;">${entry.relative}</td>
        </tr>
        <tr>
          <td style="padding: var(--gap-xs) var(--gap-md) var(--gap-xs) 0; color: var(--ink-faint); font-family: var(--font-mono); font-size: var(--text-xs);">CATEGORY</td>
          <td style="padding: var(--gap-xs) 0;">${entry.category}</td>
        </tr>
        ${entry.mtime ? `
        <tr>
          <td style="padding: var(--gap-xs) var(--gap-md) var(--gap-xs) 0; color: var(--ink-faint); font-family: var(--font-mono); font-size: var(--text-xs);">MODIFIED</td>
          <td style="padding: var(--gap-xs) 0; font-family: var(--font-mono);">${new Date(entry.mtime).toLocaleString()}</td>
        </tr>` : ''}
        ${entry.size != null ? `
        <tr>
          <td style="padding: var(--gap-xs) var(--gap-md) var(--gap-xs) 0; color: var(--ink-faint); font-family: var(--font-mono); font-size: var(--text-xs);">SIZE</td>
          <td style="padding: var(--gap-xs) 0; font-family: var(--font-mono);">${(entry.size / 1024).toFixed(1)} KB</td>
        </tr>` : ''}
      </table>
    </div>
  `;
});

document.addEventListener('sketch:new', () => {
  projectMain.innerHTML = `
    <div style="color:var(--ink-muted); font-size:var(--text-sm); text-align:center;">
      <div style="font-size:2rem; opacity:0.3; margin-bottom:var(--gap-md);">✏️</div>
      Sketch pad — Phase 4
    </div>
  `;
});
