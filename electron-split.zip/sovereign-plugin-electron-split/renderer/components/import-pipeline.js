'use strict';

// Phase 3 — Import Pipeline
// 1. User clicks Import → file picker (any type)
// 2. Files are sent to main process for security scanning
// 3. Security report modal shows findings
// 4. If clean (or user overrides): Toggle Divide modal offers split
// 5. Split is optional — user confirms before write
// 6. Entries land in the correct virtual project category

import { getVfsPath } from './enclave.js';

// ── Security report renderer ──────────────────────────────────

function renderSecurityBanner(report, quarantined, blocked) {
  const total = (quarantined || 0) + (blocked || 0);
  if (total === 0 && report.clean) {
    return `
      <div class="security-banner clean">
        <span class="sec-icon">✅</span>
        <div class="sec-body">
          <div class="sec-title">Security scan passed</div>
          <div class="sec-detail">${report.filesScanned} file(s) scanned — no critical or high findings</div>
        </div>
      </div>`;
  }
  const counts = report.findingCounts;
  const parts = ['CRITICAL','HIGH','MEDIUM','LOW']
    .filter(s => counts[s] > 0)
    .map(s => `${counts[s]} ${s.toLowerCase()}`).join(', ');
  const cls = (counts.CRITICAL || counts.HIGH) ? 'blocked' : 'warning';
  return `
    <div class="security-banner ${cls}">
      <span class="sec-icon">${cls === 'blocked' ? '🚫' : '⚠️'}</span>
      <div class="sec-body">
        <div class="sec-title">${blocked} file(s) blocked · ${quarantined} quarantined</div>
        <div class="sec-detail">${parts} — review findings below before proceeding</div>
      </div>
    </div>`;
}

function renderFindingsList(findings) {
  if (!findings || !findings.length) return '';
  const rows = findings.slice(0, 20).map(f => `
    <div class="finding-row">
      <span class="severity-badge severity-${f.severity}">${f.severity}</span>
      <span style="color:var(--cream-dim)">${f.label}</span>
      <span style="color:var(--ink-faint)">line ${f.line}</span>
      <span style="color:var(--ink-faint); overflow:hidden; text-overflow:ellipsis;">${f.excerpt}</span>
    </div>`).join('');
  return `<div class="finding-list">${rows}</div>`;
}

function renderImportResults(imported) {
  return imported.map(r => {
    const icon = r.status === 'clean' ? '✅'
      : r.status === 'imported-with-warnings' ? '⚠️'
      : r.status === 'quarantined' ? '🔒'
      : r.status === 'blocked' ? '🚫'
      : '❌';
    const allFindings = r.findings || [];
    const findingsHtml = allFindings.length ? renderFindingsList(allFindings) : '';
    return `
      <div class="import-result-row ${r.status}">
        <span class="status-icon">${icon}</span>
        <span class="file-label" title="${r.src || r.name}">${r.name}</span>
        <span class="status-text">${r.reason || r.status}</span>
      </div>
      ${findingsHtml}`;
  }).join('');
}

// ── Toggle Divide modal ───────────────────────────────────────

let splitterWorker = null;

function getSplitter() {
  if (!splitterWorker) {
    splitterWorker = new Worker('../workers/file-splitter.worker.js');
  }
  return splitterWorker;
}

async function splitFile(fileName, content) {
  return new Promise((resolve) => {
    const worker = getSplitter();
    const handler = (e) => {
      if (e.data.type === 'result') {
        worker.removeEventListener('message', handler);
        resolve(e.data.pieces);
      }
    };
    worker.addEventListener('message', handler);
    worker.postMessage({ type: 'split', fileName, content });
  });
}

async function showDivideModal(cleanFiles) {
  return new Promise((resolve) => {
    const backdrop = document.createElement('div');
    backdrop.classList.add('modal-backdrop');

    // Analyse files that can be split
    const splittable = cleanFiles.filter(f =>
      /\.(js|ts|jsx|tsx|mjs|html|htm|css)$/i.test(f.name)
    );

    backdrop.innerHTML = `
      <div class="modal">
        <div class="modal-header">
          <span class="modal-title">Toggle Divide</span>
          <button class="modal-close" id="divide-close">✕</button>
        </div>
        <div class="modal-body">
          <p style="font-size:var(--text-sm); color:var(--ink-muted); margin-bottom:var(--gap-md);">
            ${splittable.length} file(s) can be split into typed components.
            Split pieces land in the correct category automatically.
          </p>
          <div id="divide-previews" style="display:flex; flex-direction:column; gap:var(--gap-md);">
            <div style="color:var(--ink-faint); font-size:var(--text-xs);">Analysing…</div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" id="divide-skip">Import without splitting</button>
          <button class="btn btn-primary" id="divide-confirm">Split &amp; import</button>
        </div>
      </div>`;

    document.body.appendChild(backdrop);
    requestAnimationFrame(() => backdrop.classList.add('open'));

    const previews = backdrop.querySelector('#divide-previews');
    let allPieces = [];

    // Generate previews async
    (async () => {
      if (!splittable.length) {
        previews.innerHTML = '<div style="color:var(--ink-faint);font-size:var(--text-sm);">No splittable files in this import.</div>';
        return;
      }
      previews.innerHTML = '';
      for (const f of splittable) {
        let content = '';
        try { content = await window.electronAPI.readFile(null, f.src) || f.content || ''; } catch {}
        const pieces = await splitFile(f.name, content);
        allPieces.push(...pieces.map(p => ({ ...p, sourceFile: f.name })));

        const block = document.createElement('div');
        block.innerHTML = `
          <div style="font-size:var(--text-xs); color:var(--ink-faint); font-family:var(--font-mono); margin-bottom:4px;">${f.name}</div>
          <div class="divide-preview">
            ${pieces.map(p => `
              <div class="divide-piece">
                <span class="piece-name">${p.name}</span>
                <span class="piece-cat">${p.category}</span>
                <span class="piece-lines">${p.content.split('\n').length} lines</span>
              </div>`).join('')}
          </div>`;
        previews.appendChild(block);
      }
    })();

    function close(split) {
      backdrop.classList.remove('open');
      setTimeout(() => backdrop.remove(), 300);
      resolve({ split, pieces: split ? allPieces : [] });
    }

    backdrop.querySelector('#divide-close').addEventListener('click', () => close(false));
    backdrop.querySelector('#divide-skip').addEventListener('click', () => close(false));
    backdrop.querySelector('#divide-confirm').addEventListener('click', () => close(true));
  });
}

// ── Security report modal ─────────────────────────────────────

function showSecurityModal(importResult) {
  return new Promise((resolve) => {
    const { imported, securityReport } = importResult;
    const quarantined = imported.filter(f => f.status === 'quarantined').length;
    const blocked = imported.filter(f => f.status === 'blocked').length;
    const hasUnsafe = quarantined > 0;

    const backdrop = document.createElement('div');
    backdrop.classList.add('modal-backdrop');
    backdrop.innerHTML = `
      <div class="modal" style="width:min(560px,92vw);">
        <div class="modal-header">
          <span class="modal-title">Import Security Report</span>
          <button class="modal-close" id="sec-close">✕</button>
        </div>
        <div class="modal-body">
          ${renderSecurityBanner(securityReport, quarantined, blocked)}
          <div class="import-result-list">
            ${renderImportResults(imported)}
          </div>
          ${hasUnsafe ? `
            <div class="override-warning">
              ⚠️ ${quarantined} file(s) quarantined due to high-severity findings.
              Importing these files may expose the application to security risks.
              Only override if you trust the source.
            </div>` : ''}
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" id="sec-cancel">Cancel</button>
          ${hasUnsafe ? `<button class="btn btn-danger" id="sec-override">Import anyway</button>` : ''}
          <button class="btn btn-primary" id="sec-continue">
            ${blocked || quarantined ? 'Continue with safe files' : 'Continue'}
          </button>
        </div>
      </div>`;

    document.body.appendChild(backdrop);
    requestAnimationFrame(() => backdrop.classList.add('open'));

    function close(action) {
      backdrop.classList.remove('open');
      setTimeout(() => backdrop.remove(), 300);
      resolve(action);
    }

    backdrop.querySelector('#sec-close').addEventListener('click', () => close('cancel'));
    backdrop.querySelector('#sec-cancel').addEventListener('click', () => close('cancel'));
    backdrop.querySelector('#sec-continue').addEventListener('click', () => close('continue'));
    backdrop.querySelector('#sec-override')?.addEventListener('click', () => close('override'));
  });
}

// ── Main import flow ──────────────────────────────────────────

export async function runImport() {
  const vfsPath = getVfsPath();

  // 1. File picker
  const filePaths = await window.electronAPI.importFiles();
  if (!filePaths || !filePaths.length) return;

  // 2. Security scan + copy clean files
  const importResult = await window.electronAPI.processImport(filePaths, vfsPath, false);

  // 3. Security report modal
  const action = await showSecurityModal(importResult);
  if (action === 'cancel') return;

  let finalImported = importResult.imported;

  // 4. If user chose to override quarantined files — re-run with override flag
  if (action === 'override') {
    const quarantinedPaths = importResult.imported
      .filter(f => f.status === 'quarantined')
      .map(f => f.src);
    if (quarantinedPaths.length) {
      const overrideResult = await window.electronAPI.processImport(quarantinedPaths, vfsPath, true);
      finalImported = [
        ...finalImported.filter(f => f.status !== 'quarantined'),
        ...overrideResult.imported,
      ];
    }
  }

  // 5. Toggle Divide modal for clean/imported files
  const cleanFiles = finalImported.filter(f =>
    f.status === 'clean' || f.status === 'imported-with-warnings'
  );

  const { split, pieces } = await showDivideModal(cleanFiles);

  // 6. Build final entry list for file browser
  const entries = [];
  if (split && pieces.length) {
    for (const piece of pieces) {
      // Write each split piece into vfs
      if (vfsPath) {
        try {
          await window.electronAPI.saveFile(vfsPath, piece.name, piece.content);
        } catch (err) {
          console.warn('Security blocked split piece save:', err.message);
          continue;
        }
      }
      entries.push({
        name: piece.name,
        path: vfsPath ? `${vfsPath}/${piece.name}` : `vfs://${piece.name}`,
        relative: piece.name,
        category: piece.category,
        isDir: false,
        mtime: new Date().toISOString(),
        virtual: !vfsPath,
      });
    }
  } else {
    for (const f of cleanFiles) {
      entries.push({
        name: f.name,
        path: f.src || `vfs://${f.name}`,
        relative: f.relative || f.name,
        category: f.category || 'DOCUMENTS',
        isDir: false,
        mtime: new Date().toISOString(),
        hash: f.hash,
      });
    }
  }

  // 7. Notify file browser
  document.dispatchEvent(new CustomEvent('import:complete', { detail: { entries } }));
}
