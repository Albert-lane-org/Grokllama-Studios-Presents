'use strict';

const CATEGORIES = ['FOLDERS', 'PAGES', 'STYLESHEETS', 'DOCUMENTS', 'DATA', 'SCRIPTS', 'ASSETS'];

const CAT_ICONS = {
  FOLDERS: '📁', PAGES: '🌐', STYLESHEETS: '🎨',
  DOCUMENTS: '📄', DATA: '📊', SCRIPTS: '⚙️', ASSETS: '🖼️',
};

const EXT_LABELS = {
  html: 'HTML', htm: 'HTML', css: 'CSS', js: 'JS', ts: 'TS',
  jsx: 'JSX', tsx: 'TSX', md: 'MD', txt: 'TXT', json: 'JSON',
  csv: 'CSV', xml: 'XML', png: 'PNG', jpg: 'JPG', svg: 'SVG',
  pdf: 'PDF', docx: 'DOCX',
};

let fileEntries = [];
let showAll = false;

// ── State ────────────────────────────────────────────────────
function groupByCategory(entries) {
  const groups = {};
  for (const cat of CATEGORIES) groups[cat] = [];
  for (const entry of entries) {
    if (!entry.isDir) groups[entry.category]?.push(entry);
    else groups['FOLDERS']?.push(entry);
  }
  return groups;
}

function getExt(name) {
  const parts = name.split('.');
  return parts.length > 1 ? parts[parts.length - 1].toLowerCase() : '';
}

function formatMtime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

// ── Render ───────────────────────────────────────────────────
function renderTree() {
  const container = document.getElementById('file-tree');
  const empty = document.getElementById('empty-state');

  if (!fileEntries.length) {
    empty.style.display = '';
    container.innerHTML = '';
    container.appendChild(empty);
    return;
  }

  empty.style.display = 'none';
  const groups = groupByCategory(fileEntries);
  const populated = new Set(CATEGORIES.filter((c) => groups[c].length > 0));

  container.innerHTML = '';

  for (const cat of CATEGORIES) {
    const files = groups[cat];
    const isEmpty = files.length === 0;
    if (isEmpty && !showAll) continue;

    const details = document.createElement('details');
    details.classList.add('category-section');
    if (isEmpty) details.classList.add('empty-cat');
    if (!isEmpty) details.open = true;

    const summary = document.createElement('summary');
    summary.classList.add('category-header');
    summary.innerHTML = `
      <span>${CAT_ICONS[cat] || '•'}</span>
      <span>${cat}</span>
      ${files.length ? `<span class="category-count">${files.length}</span>` : ''}
      <span class="chevron">▶</span>
    `;
    details.appendChild(summary);

    if (files.length) {
      const ul = document.createElement('div');
      ul.classList.add('file-list');
      for (const f of files) {
        const row = document.createElement('div');
        row.classList.add('file-row');
        row.dataset.path = f.path;
        const ext = getExt(f.name);
        const badge = EXT_LABELS[ext] || (f.isDir ? 'DIR' : ext.toUpperCase() || '—');
        row.innerHTML = `
          <span class="file-name" title="${f.relative}">${f.name}</span>
          <span class="file-type-badge">${badge}</span>
          <span class="file-mtime">${formatMtime(f.mtime)}</span>
        `;
        row.addEventListener('click', () => selectFile(f));
        ul.appendChild(row);
      }
      details.appendChild(ul);
    }

    container.appendChild(details);
  }
}

// ── Selection ────────────────────────────────────────────────
function selectFile(entry) {
  document.querySelectorAll('.file-row').forEach((r) => r.classList.remove('selected'));
  const row = document.querySelector(`.file-row[data-path="${CSS.escape(entry.path)}"]`);
  if (row) row.classList.add('selected');
  // Notify project tab
  document.dispatchEvent(new CustomEvent('file:selected', { detail: entry }));
}

// ── Open Folder ──────────────────────────────────────────────
async function openFolder() {
  const folderPath = await window.electronAPI.openFolder();
  if (!folderPath) return;

  const name = folderPath.split(/[\\/]/).pop();

  // Notify status bar immediately (Phase 1 path)
  document.dispatchEvent(new CustomEvent('project:opened', { detail: { path: folderPath, name } }));

  // Phase 2: spin up enclave virtual copy, then read tree from vfs
  document.dispatchEvent(new CustomEvent('enclave:starting'));
  try {
    const { vfsPath } = await window.electronAPI.createEnclave(folderPath);
    fileEntries = await window.electronAPI.readFileTree(vfsPath);
  } catch {
    // Fallback: read directly from source if enclave creation fails
    fileEntries = await window.electronAPI.readFileTree(folderPath);
  }

  renderTree();
}

// ── Drop Zone ────────────────────────────────────────────────
const dropZone = document.getElementById('drop-zone');

dropZone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropZone.classList.add('drag-over');
});
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  const paths = Array.from(e.dataTransfer.files).map((f) => f.path).filter(Boolean);
  if (paths.length) {
    for (const p of paths) {
      const name = p.split(/[\\/]/).pop();
      const ext = name.split('.').pop()?.toLowerCase() || '';
      const cat = detectCategoryFromExt(ext);
      fileEntries.push({ name, path: p, relative: name, category: cat, isDir: false, mtime: new Date().toISOString() });
    }
    renderTree();
  }
});

function detectCategoryFromExt(ext) {
  const m = {
    html: 'PAGES', htm: 'PAGES', css: 'STYLESHEETS',
    md: 'DOCUMENTS', txt: 'DOCUMENTS', pdf: 'DOCUMENTS', docx: 'DOCUMENTS',
    json: 'DATA', csv: 'DATA', xml: 'DATA',
    js: 'SCRIPTS', ts: 'SCRIPTS', jsx: 'SCRIPTS', tsx: 'SCRIPTS',
  };
  return m[ext] || 'ASSETS';
}

// ── Paste from Clipboard ─────────────────────────────────────
document.getElementById('btn-paste').addEventListener('click', async () => {
  const text = await window.electronAPI.readClipboardText();
  if (!text.trim()) return;
  const entry = {
    name: `paste-${Date.now()}.txt`,
    path: `clipboard://${Date.now()}`,
    relative: `paste-${Date.now()}.txt`,
    category: 'DOCUMENTS',
    isDir: false,
    mtime: new Date().toISOString(),
    virtual: true,
    content: text,
  };
  fileEntries.push(entry);
  renderTree();
});

// ── New Sketch ───────────────────────────────────────────────
document.getElementById('btn-new-sketch').addEventListener('click', () => {
  const name = `sketch-${Date.now()}.png`;
  fileEntries.push({
    name,
    path: `sketch://${name}`,
    relative: `sketches/${name}`,
    category: 'ASSETS',
    isDir: false,
    mtime: new Date().toISOString(),
    virtual: true,
  });
  renderTree();
  document.dispatchEvent(new CustomEvent('sketch:new'));
});

// ── Show-All Toggle ──────────────────────────────────────────
const toggleEl = document.getElementById('toggle-show-all');
const chkShowAll = document.getElementById('chk-show-all');

toggleEl.addEventListener('click', () => {
  showAll = !showAll;
  chkShowAll.checked = showAll;
  toggleEl.classList.toggle('on', showAll);
  renderTree();
});

// ── Open Folder Button ───────────────────────────────────────
document.getElementById('btn-open-folder').addEventListener('click', openFolder);

// ── Import pipeline adds entries ─────────────────────────────
document.addEventListener('filebrowser:addEntries', (e) => {
  const newEntries = e.detail;
  if (!Array.isArray(newEntries)) return;
  for (const entry of newEntries) {
    // Avoid duplicates by path
    if (!fileEntries.some(f => f.path === entry.path)) {
      fileEntries.push(entry);
    }
  }
  renderTree();
});
