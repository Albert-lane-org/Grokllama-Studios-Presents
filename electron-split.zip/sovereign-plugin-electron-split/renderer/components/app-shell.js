'use strict';

// Title bar window controls
document.getElementById('btn-minimize').addEventListener('click', () => window.electronAPI.windowMinimize());
document.getElementById('btn-maximize').addEventListener('click', () => window.electronAPI.windowMaximize());
document.getElementById('btn-close').addEventListener('click', () => window.electronAPI.windowClose());

window.electronAPI.onWindowMaximized((isMax) => {
  document.getElementById('btn-maximize').textContent = isMax ? '❐' : '□';
});

// Tab switching
const tabBtns = document.querySelectorAll('.tab-btn');
const tabPanels = document.querySelectorAll('.tab-panel');

tabBtns.forEach((btn) => {
  btn.addEventListener('click', () => {
    if (btn.disabled) return;
    const target = btn.dataset.tab;
    tabBtns.forEach((b) => b.classList.toggle('active', b.dataset.tab === target));
    tabPanels.forEach((p) => p.classList.toggle('active', p.id === `panel-${target}`));
  });
});

// Panel collapse
const filePanel = document.getElementById('file-panel');
const collapseBtn = document.getElementById('btn-collapse-panel');
let panelOpen = true;

collapseBtn.addEventListener('click', () => {
  panelOpen = !panelOpen;
  filePanel.classList.toggle('collapsed', !panelOpen);
  collapseBtn.textContent = panelOpen ? '◀' : '▶';
  collapseBtn.style.right = panelOpen ? '-12px' : '-12px';
});
