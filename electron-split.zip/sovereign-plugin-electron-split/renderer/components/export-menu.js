'use strict';

// Phase 3 — Export / Share Menu
// ↗ button top-right opens modal with:
//   Download .zip · PDF · PPTX · Standalone HTML · Claude Code handoff (active)
//   Send to Canva (stub)
//   Import (triggers import pipeline)

import { runImport } from './import-pipeline.js';
import { getVfsPath } from './enclave.js';

function createExportModal() {
  const backdrop = document.createElement('div');
  backdrop.classList.add('modal-backdrop');
  backdrop.id = 'export-modal';

  backdrop.innerHTML = `
    <div class="modal" style="width:min(460px,92vw);">
      <div class="modal-header">
        <span class="modal-title">Export · Share · Import</span>
        <button class="modal-close" id="export-close">✕</button>
      </div>
      <div class="modal-body">

        <p style="font-size:var(--text-xs); color:var(--ink-faint); font-family:var(--font-mono); letter-spacing:0.08em; margin-bottom:var(--gap-md);">IMPORT</p>
        <ul class="export-list" style="margin-bottom:var(--gap-xl);">
          <li class="export-item" id="exp-import">
            <span class="export-icon">📂</span>
            <span class="export-label">Import files</span>
            <span class="export-badge active">active</span>
          </li>
        </ul>

        <p style="font-size:var(--text-xs); color:var(--ink-faint); font-family:var(--font-mono); letter-spacing:0.08em; margin-bottom:var(--gap-md);">EXPORT</p>
        <ul class="export-list">
          <li class="export-item" id="exp-zip">
            <span class="export-icon">🗜️</span>
            <span class="export-label">Download project as .zip</span>
            <span class="export-badge active">active</span>
          </li>
          <li class="export-item" id="exp-pdf">
            <span class="export-icon">📄</span>
            <span class="export-label">Export as PDF</span>
            <span class="export-badge active">active</span>
          </li>
          <li class="export-item" id="exp-pptx">
            <span class="export-icon">📊</span>
            <span class="export-label">Export as PPTX</span>
            <span class="export-badge active">active</span>
          </li>
          <li class="export-item" id="exp-html">
            <span class="export-icon">🌐</span>
            <span class="export-label">Export as standalone HTML</span>
            <span class="export-badge active">active</span>
          </li>
          <li class="export-item stub" id="exp-canva">
            <span class="export-icon">🎨</span>
            <span class="export-label">Send to Canva</span>
            <span class="export-badge">stub</span>
          </li>
          <li class="export-item" id="exp-claude">
            <span class="export-icon">⚡</span>
            <span class="export-label">Handoff to Claude Code</span>
            <span class="export-badge active">active</span>
          </li>
        </ul>

      </div>
    </div>`;

  document.body.appendChild(backdrop);
  requestAnimationFrame(() => backdrop.classList.add('open'));

  function close() {
    backdrop.classList.remove('open');
    setTimeout(() => backdrop.remove(), 300);
  }

  backdrop.querySelector('#export-close').addEventListener('click', close);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });

  // Import
  backdrop.querySelector('#exp-import').addEventListener('click', async () => {
    close();
    await runImport();
  });

  // Zip
  backdrop.querySelector('#exp-zip').addEventListener('click', async () => {
    close();
    const vfsPath = getVfsPath();
    if (!vfsPath) return showToast('No active project — open a folder first');
    await window.electronAPI.exportZip(vfsPath);
  });

  // PDF
  backdrop.querySelector('#exp-pdf').addEventListener('click', async () => {
    close();
    await window.electronAPI.exportPDF();
  });

  // PPTX
  backdrop.querySelector('#exp-pptx').addEventListener('click', async () => {
    close();
    const vfsPath = getVfsPath();
    if (!vfsPath) return showToast('No active project — open a folder first');
    await window.electronAPI.exportPPTX(vfsPath);
  });

  // Standalone HTML
  backdrop.querySelector('#exp-html').addEventListener('click', async () => {
    close();
    const vfsPath = getVfsPath();
    if (!vfsPath) return showToast('No active project — open a folder first');
    await window.electronAPI.exportStandaloneHTML(vfsPath);
  });

  // Canva stub
  backdrop.querySelector('#exp-canva').addEventListener('click', () => {
    showToast('Canva integration — coming soon');
  });

  // Claude Code handoff
  backdrop.querySelector('#exp-claude').addEventListener('click', async () => {
    close();
    const vfsPath = getVfsPath();
    if (!vfsPath) return showToast('No active project — open a folder first');
    await window.electronAPI.handoffToClaudeCode(vfsPath);
    showToast('Handoff written — open your terminal and run: claude --project <path>');
  });
}

function showToast(msg) {
  const el = document.createElement('div');
  el.style.cssText = `
    position: fixed; bottom: 40px; left: 50%; transform: translateX(-50%);
    background: var(--navy-light); border: 1px solid var(--border-mid);
    color: var(--cream); padding: 8px 18px; border-radius: var(--radius-md);
    font-size: var(--text-sm); z-index: 200; box-shadow: var(--shadow-md);
    animation: fadeIn 0.2s ease;
  `;
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

// Mount export button
const exportBtn = document.createElement('button');
exportBtn.id = 'btn-export';
exportBtn.title = 'Export / Import';
exportBtn.innerHTML = '↗';
document.body.appendChild(exportBtn);
exportBtn.addEventListener('click', createExportModal);

// Listen for import:complete → add entries to file browser
document.addEventListener('import:complete', (e) => {
  document.dispatchEvent(new CustomEvent('filebrowser:addEntries', { detail: e.detail.entries }));
});
