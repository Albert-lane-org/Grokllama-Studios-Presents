'use strict';

const pillEnclave = document.getElementById('pill-enclave');
const labelBranch = document.getElementById('label-branch');

function setPill(cls, dot, text) {
  pillEnclave.className = `status-pill ${cls}`;
  pillEnclave.innerHTML = `<span class="status-dot"></span> ${text}`;
}

document.addEventListener('project:opened', (e) => {
  const { name } = e.detail;
  setPill('local', true, `vfs://${name}`);
  labelBranch.textContent = 'local';
});

document.addEventListener('enclave:starting', () => {
  setPill('syncing', true, 'creating enclave…');
});

document.addEventListener('enclave:activated', (e) => {
  const { uuid, projectName } = e.detail;
  const shortId = uuid ? uuid.slice(0, 8) : '—';
  setPill('local', true, `vfs://${projectName} · ${shortId}`);
  labelBranch.textContent = 'local';
});

document.addEventListener('enclave:syncing', () => {
  setPill('syncing', true, 'syncing…');
});

document.addEventListener('enclave:synced', (e) => {
  const { uuid, projectName } = e.detail || {};
  const shortId = uuid?.slice(0, 8) || 'local';
  setPill('local', true, `vfs://${projectName || 'project'} · ${shortId}`);
});

document.addEventListener('enclave:error', (e) => {
  setPill('', true, `enclave error`);
  pillEnclave.style.color = 'var(--danger)';
  pillEnclave.style.borderColor = 'var(--danger)';
});
