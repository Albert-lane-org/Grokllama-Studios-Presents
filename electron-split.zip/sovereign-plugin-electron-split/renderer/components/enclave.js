'use strict';

// Phase 2 — Enclave UI controller
// Manages the virtual project lifecycle from the renderer side:
//   - Shows a progress modal while the working copy is created
//   - Updates the status bar with vfs path, UUID, and sync state
//   - Stores vfsPath in module state so other components can read it

let _vfsPath = null;
let _uuid = null;

export function getVfsPath() { return _vfsPath; }
export function getUUID() { return _uuid; }

// ── Progress Modal ────────────────────────────────────────────

function createProgressModal() {
  const backdrop = document.createElement('div');
  backdrop.classList.add('modal-backdrop');
  backdrop.id = 'enclave-progress-modal';

  backdrop.innerHTML = `
    <div class="modal" style="width: min(420px, 90vw);">
      <div class="modal-header">
        <span class="modal-title">Creating Virtual Project</span>
      </div>
      <div class="modal-body">
        <div id="enclave-progress-stage" style="color:var(--ink-muted); font-size:var(--text-sm); margin-bottom:var(--gap-md);">
          Initialising…
        </div>
        <div style="background:var(--border-subtle); border-radius:99px; height:4px; overflow:hidden;">
          <div id="enclave-progress-bar" style="height:100%; width:0%; background:var(--gold); border-radius:99px; transition:width 0.3s var(--ease-out);"></div>
        </div>
        <div id="enclave-progress-file" style="color:var(--ink-faint); font-size:var(--text-xs); font-family:var(--font-mono); margin-top:var(--gap-sm); min-height:1.4em; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;"></div>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);
  requestAnimationFrame(() => backdrop.classList.add('open'));
  return backdrop;
}

function removeProgressModal(backdrop) {
  backdrop.classList.remove('open');
  setTimeout(() => backdrop.remove(), 300);
}

// ── Main flow ─────────────────────────────────────────────────

export async function activateEnclave(sourcePath) {
  const modal = createProgressModal();
  const stageEl = document.getElementById('enclave-progress-stage');
  const barEl = document.getElementById('enclave-progress-bar');
  const fileEl = document.getElementById('enclave-progress-file');

  let fileCount = 0;

  window.electronAPI.onEnclaveProgress((payload) => {
    if (payload.stage === 'copy') {
      stageEl.textContent = 'Copying files…';
      barEl.style.width = '40%';
      if (payload.file) {
        fileEl.textContent = payload.file;
        fileCount++;
      }
    } else if (payload.stage === 'manifest') {
      stageEl.textContent = 'Computing checksums…';
      barEl.style.width = '75%';
      fileEl.textContent = `${fileCount} files copied`;
    } else if (payload.stage === 'done') {
      stageEl.textContent = 'Done.';
      barEl.style.width = '100%';
      fileEl.textContent = payload.vfsPath || '';
    }
  });

  try {
    barEl.style.width = '10%';
    stageEl.textContent = 'Starting copy…';

    const result = await window.electronAPI.createEnclave(sourcePath);
    _vfsPath = result.vfsPath;
    _uuid = result.uuid;

    removeProgressModal(modal);

    // Notify status bar
    document.dispatchEvent(new CustomEvent('enclave:activated', {
      detail: { vfsPath: result.vfsPath, uuid: result.uuid, projectName: result.projectName },
    }));

    return result;
  } catch (err) {
    stageEl.textContent = `Error: ${err.message}`;
    stageEl.style.color = 'var(--danger)';
    barEl.style.background = 'var(--danger)';
    barEl.style.width = '100%';
    // Leave modal open so user can read the error; close on click
    modal.addEventListener('click', () => removeProgressModal(modal), { once: true });
    throw err;
  }
}
